# Ascal

Ask ai -> Ascal

This is a python library that provides a simple way to generate quiz questions.
